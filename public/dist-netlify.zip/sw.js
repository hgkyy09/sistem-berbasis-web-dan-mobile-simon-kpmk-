/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "1872c500de691dce40960bb85481de07"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "08acb22a058c16521840ca673e0f48a5"
  }, {
    "url": "pwa-512x512.png",
    "revision": "08acb22a058c16521840ca673e0f48a5"
  }, {
    "url": "pwa-192x192.png",
    "revision": "36e166e0d012bb3a9955e6eac5571a5b"
  }, {
    "url": "index.html",
    "revision": "51af38b22ed3e0aea8a35bd7c8f1a0cf"
  }, {
    "url": "icon.svg",
    "revision": "74951490ea1ab6e016eb74c0f9b6e4de"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "aaf9591ac5975c38edab003d1d8a1f59"
  }, {
    "url": "assets/index-CtG9oSeC.css",
    "revision": null
  }, {
    "url": "assets/index-69NshV2d.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "aaf9591ac5975c38edab003d1d8a1f59"
  }, {
    "url": "icon.svg",
    "revision": "74951490ea1ab6e016eb74c0f9b6e4de"
  }, {
    "url": "pwa-192x192.png",
    "revision": "36e166e0d012bb3a9955e6eac5571a5b"
  }, {
    "url": "pwa-512x512.png",
    "revision": "08acb22a058c16521840ca673e0f48a5"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "08acb22a058c16521840ca673e0f48a5"
  }, {
    "url": "manifest.webmanifest",
    "revision": "3e461e25cdd6af21e9197926d35de9e2"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
